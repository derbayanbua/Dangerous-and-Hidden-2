@echo off
rem Freigabe fuer Mehrspieler im LAN: Spielport UDP 11001, Serverabfrage UDP 11002, LAN-Suche UDP 27101.
rem Rechtsklick -> "Als Administrator ausfuehren".
set EXE=%~dp0DangerousHidden2.exe
netsh advfirewall firewall delete rule name="Dangerous and Hidden 2" >nul 2>&1
netsh advfirewall firewall add rule name="Dangerous and Hidden 2" dir=in action=allow program="%EXE%" enable=yes profile=private,domain
netsh advfirewall firewall add rule name="Dangerous and Hidden 2" dir=in action=allow protocol=UDP localport=11001,11002,27101 enable=yes profile=private,domain
echo.
echo Freigabe eingerichtet (Netzwerkprofil "Privat" bzw. "Domaene").
pause
